﻿using System;
using System.Threading.Tasks;
using AsyncAwait.Task2.CodeReviewChallenge.Headers;
using CloudServices.Interfaces;
using Microsoft.AspNetCore.Http;

namespace AsyncAwait.Task2.CodeReviewChallenge.Middleware;

public class StatisticMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IStatisticService _statisticService;

    public StatisticMiddleware(RequestDelegate next, IStatisticService statisticService)
    {
        _next = next;
        _statisticService = statisticService ?? throw new ArgumentNullException(nameof(statisticService));
    }

    public async Task InvokeAsync(HttpContext context)
    {
        string path = context.Request.Path;

        try
        {
            await _statisticService.RegisterVisitAsync(path).ConfigureAwait(false);
            var count = await _statisticService.GetVisitsCountAsync(path).ConfigureAwait(false);
            var countString = count.ToString();
            context.Response.Headers[CustomHttpHeaders.TotalPageVisits] = countString;
            context.Items[CustomHttpHeaders.TotalPageVisits] = countString;
        }
        catch
        {
        }

        await _next(context).ConfigureAwait(false);
    }
}
